作者：白丰硕
学号：71116233
内容：Syntax Parser Programming
文件夹目录结构及其内容：
·
|——dist
|   ├── syntax.exe      # 在cmd中运行exe文件，使用参数在报告中有所介绍（一定要将PPT.xlsx文件在该文件下，否则不能运行）
|   └── other           # 其他的dll库
|——example
|   ├── example1.cpp
|   └── example2.cpp    # 主要是包含对循环、选择、返回、比较运算符表达式、算术运算表达式等语法分析处理功能展示
|——derivation           # 示例文件的语法推导序列文件
|——syntax.py            # 语法分析源代码
|——BNFmyself.txt        # 个人修改整理过后的BNF
|——PPX.xlsx             # sheet1是预测分析表 sheet2是产生式序号对应表
└──编译原理实验报告二.pdf