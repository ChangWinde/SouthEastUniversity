#include<math>

using namespace std
int b;
void main(){
    int a=1;
    while(a+2>=b*4){
        c = 4;
    }
    return ;
}