#include<iostream>
using namespace std
int inc(int a,float b){
  void q = 2;
  if(1+a >= b*2)
    c = 1;
  else
    c=2;
  return ;
}
int main(){
  int a=1;
  return;
}
