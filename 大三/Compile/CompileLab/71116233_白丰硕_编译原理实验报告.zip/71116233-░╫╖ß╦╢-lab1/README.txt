﻿作者：白丰硕
学号：71116233
内容：Lexical Analyzer Programming
文件夹目录结构及其内容：
·
|——dist
|   ├── lex.exe         # 在cmd中运行exe文件，使用参数在报告中有所介绍
|   └── other           # 其他的dll库
|——example
|   ├── example1.cpp
|   ├── example2.cpp
|   ├── example3.cpp
|   └── example4.cpp    # 主要是包含词法分析中错误处理功能展示
|——token                # 示例文件的token序列文件
|——lex.py               # 词法分析源代码
└──编译原理实验报告一.pdf