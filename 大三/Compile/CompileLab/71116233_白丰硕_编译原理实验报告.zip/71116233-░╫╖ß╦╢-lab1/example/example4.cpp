//这个文件主要展示可以处理的错误
int a = 1;
//浮点数错误
double b = 1.2.3;
//数字错误
int c = 12a;
//字符错误
char d = 'abc';
char e = 'a
//字符串错误
string = "123"
string = "abcd
//注释错误
/*我是一个错误的注释
//标识符错误
int sj@#!;
